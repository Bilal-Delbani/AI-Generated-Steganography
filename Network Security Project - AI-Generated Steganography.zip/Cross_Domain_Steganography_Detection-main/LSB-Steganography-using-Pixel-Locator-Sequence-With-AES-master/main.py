import LSB as lsb
import AES as Cipher
import os
import time


def main():
    select = input("Enter E for Encoding D for Decoding :")
    if select == 'E':
        coverpath = r"C:\Users\HES\Desktop\Cross_Domain_Steganography_Detection-main\LSB-Steganography-using-Pixel-Locator-Sequence-With-AES-master\COVER"
        outpath = r"C:\Users\HES\Desktop\Cross_Domain_Steganography_Detection-main\LSB-Steganography-using-Pixel-Locator-Sequence-With-AES-master\OUT"
        images=os.listdir(coverpath)
        print(images)

        for j in range(1,15):
            if os.path.exists("OUT/out{}.png".format(j)):
                os.remove("OUT/out{}.png".format(j))

            if os.path.exists("credentials{}.txt".format(j)):
                os.remove("credentials{}.txt".format(j))


            if os.path.exists("out{}.txt".format(j)):
                os.remove("out{}.txt".format(j))
            

            if os.path.exists("pls{}.txt".format(j)):
                os.remove("pls{}.txt".format(j))

            if os.path.exists("pls{}.txt.enc".format(j)):
                os.remove("pls{}.txt.enc".format(j))

        start_time = time.time()
        for i in range(0,14):

            if os.path.exists("COVER/in{}.png".format(i+1)):
                secretMessage = input("Enter the secret message :")
                passwordText = input("Password :")
                encodedMessage = Cipher.encrypt(secretMessage, passwordText,i+1)
                print(encodedMessage)
                lsb.LsbEncoding(os.path.join(coverpath, images[i]), encodedMessage, outpath,i+1)
                if os.path.exists("pls{}.txt".format(i+1)):
                    os.remove("pls{}.txt".format(i+1))
            else : print("Image is not Present")
        end_time = time.time()
        print("Encryption time:", end_time - start_time, "seconds")



    if select == 'D':
        start_time = time.time()
        for i in range (0,14):
            if os.path.exists("pls{}.txt.enc".format(i+1)):
                decodedText = lsb.LsbDecoding(i+1)
                print(decodedText)
                password = input("Enter the password :")
                finalMessage = Cipher.decrypt(decodedText, password,i+1)
                print("Final message :", finalMessage)
            else :
                print("PLS file is not present !")
        end_time = time.time()
        print("Decryption time:", end_time - start_time, "seconds")







main()


