import hashlib
import random
import os
import numpy as np
from PIL import Image

import PLShandler as plsh



def DataListInBit(data):
    dataBits = list(format(c, '08b') for c in bytearray(data.encode('latin-1')))
    return dataBits


def PLSgen(row, col, lenEncodedText,count):
    PLS = []
    new = []
    for i in range(row * col):
        new.append(i)
    for i in range(len(new) - 1, 0, -1):
        j = random.randint(0, i + 1)
        new[i], new[j] = new[j], new[i]
    for i in range(lenEncodedText * 3):
        PLS.append(new[i])
    pixelLocaterSequence = np.array(PLS)
    np.savetxt("pls{}.txt".format(count), pixelLocaterSequence, delimiter="\t")
    return PLS



def LsbEncoding(image_path,encodedText,outdir,count):
    img = Image.open(image_path)
    [row, col] = img.size
    print("Image size:", (row, col))  # Debug print

    print(img)
    PLS=PLSgen(row, col, len(encodedText),count)
    dataBits = DataListInBit(encodedText)
    dr = 0

    for i in range(0, len(encodedText) * 3, 3):
        dc = 0
        for j in range(0, 3):
            rr = PLS[i + j] // col

            rc = PLS[i + j] % col

            rgb = img.getpixel((rr, rc))
            value = []
            idx = 0
            for k in rgb:
                if (k % 2 == 0 and dataBits[dr][dc] == '1'):
                    if (k == 0):
                        k += 1
                    else:
                        k -= 1
                if (k % 2 == 1 and dataBits[dr][dc] == '0'):
                    k -= 1
                value.append(k)
                idx += 1
                dc += 1
                if (dc >= 8):
                    break
            if (dc >= 8):
                value.append(rgb[2])
            newrgb = (value[0], value[1], value[2])
            img.putpixel((rr, rc), newrgb)
        dr += 1

    filename = "out{}.png".format(count)
    outpath = os.path.join(outdir, filename)
    img.save(outpath)
    plsPassword = "dfkjbsdkjbv"
    key = hashlib.sha256(plsPassword.encode()).digest()
    plsh.encrypt_file(key, 'pls{}.txt'.format(count))



def LsbDecoding(count):
    plspassword = "dfkjbsdkjbv"
    key = hashlib.sha256(plspassword.encode()).digest()
    plsh.decrypt_file(key, 'pls{}.txt.enc'.format(count), 'out{}.txt'.format(count), chunksize=24 * 1024)
    pls = np.genfromtxt('out{}.txt'.format(count), delimiter='\t')
    if os.path.exists("out{}.txt".format(count)):
        os.remove("out{}.txt".format(count))
    if os.path.exists("pls{}.txt.enc".format(count)):
        os.remove("pls{}.txt.enc".format(count))
    decodedTextInBits = []
    stegoImage = Image.open(r"OUT/out{}.png".format(count))
    [row, col] = stegoImage.size
    print("Image size:", (row, col))  # Debug print
    for i in range(0, len(pls), 3):
        ithChar = ""
        for j in range(0, 3):
            rr = pls[i + j] // col
            rc = pls[i + j] % col
            rgb = stegoImage.getpixel((rr, rc))
            for k in rgb:
                if (k & 1):
                    ithChar += '1'
                else:
                    ithChar += '0'

        ithChar = ithChar[:-1]
        decodedTextInBits.append((ithChar))
    decodedText = ''
    for i in decodedTextInBits:
        decodedText += chr(int(i, 2))
    return decodedText
