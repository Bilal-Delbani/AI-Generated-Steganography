from math import log10, sqrt
import cv2
import numpy as np

def PSNR(original, compressed):
    mse = np.mean((original - compressed) ** 2)
    err = np.sum((original.astype("float") - compressed.astype("float")) ** 2)
    err /= float(original.shape[0] * original.shape[1])
    if (mse == 0):
        return 100
    max_pixel = 255.0
    print("MSE ", mse)
    psnr = 20 * log10(max_pixel / sqrt(mse))
    return psnr

def main():
    for i in range(1,15):
        original = cv2.imread("COVER/in{}.png".format(i))
        compressed = cv2.imread("OUT/out{}.png".format(i))
        value = PSNR(original, compressed)
        print(f"PSNR value {i} is: {value} dB")

if __name__ == "__main__":
    main()