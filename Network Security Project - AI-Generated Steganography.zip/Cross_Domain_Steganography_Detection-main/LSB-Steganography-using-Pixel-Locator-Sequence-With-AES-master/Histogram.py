import cv2
from matplotlib import pyplot as plt

for i in range(1,15):
    img = cv2.imread('COVER/in{}.png'.format(i), 1)
    plt.hist(img.ravel(),256,[0,256])
    plt.show()


for i in range(1,15):
    img = cv2.imread('OUT/out{}.png'.format(i), 1)
    plt.hist(img.ravel(),256,[0,256])
    plt.show()

