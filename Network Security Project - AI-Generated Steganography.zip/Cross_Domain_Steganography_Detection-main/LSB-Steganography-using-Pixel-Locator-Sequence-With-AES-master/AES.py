import binascii
import pbkdf2
import pyaes
import secrets
import PLShandler as plsh
import hashlib
import numpy as np



def bytes_to_int(bytes_obj):
    return int.from_bytes(bytes_obj, byteorder='big')



def encrypt(raw, password,count):
    iv = secrets.token_bytes(16)
    iv_int = bytes_to_int(iv)

    new_salt = secrets.token_bytes(16)

    file = open("credentials{}.txt".format(count), "wb")
    file.write(iv + b'\n')
    file.write(new_salt)


    key = pbkdf2.PBKDF2(password, new_salt).read(32)
    aes = pyaes.AESModeOfOperationCTR(key, pyaes.Counter(iv_int))
    cipherByte = aes.encrypt(raw)
    return binascii.hexlify(cipherByte).decode('utf-8')


def decrypt(cipherText, password,count):
    res = bytes(cipherText, 'utf-8')
    cipherByte = binascii.unhexlify(res)

    with open('credentials{}.txt'.format(count), 'rb') as file:
        lines = file.readlines()

    
    iv = lines[0].strip()
    iv_int = bytes_to_int(iv)
    passwordSalt = lines[1]

    key = pbkdf2.PBKDF2(password, passwordSalt).read(32)
    aes = pyaes.AESModeOfOperationCTR(key, pyaes.Counter(iv_int))
    originalByte = aes.decrypt(cipherByte)
    return originalByte.decode('utf-8')
